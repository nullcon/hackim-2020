
import sys
import struct
import base64

buf = b'sssssssssssssssssss'
buf += struct.pack('<Q', 10568091522599588952)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
