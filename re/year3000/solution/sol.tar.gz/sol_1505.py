
import sys
import struct
import base64

buf = b'XXXXXXXXXXXXXXXXXXX'
buf += struct.pack('<Q', 2812035686981684312)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
