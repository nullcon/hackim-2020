
import sys
import struct
import base64

buf = b'cccccccccc'
buf += struct.pack('<Q', 13435866600005722685)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
