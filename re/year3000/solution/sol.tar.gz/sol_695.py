
import sys
import struct
import base64

buf = b'DDDDDDDDDDDDD'
buf += struct.pack('<Q', 6542093898752771193)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
