
#include <stdio.h>
#include <stdint.h>
#include <string.h>

uint64_t canary = 0x73591d8338a35a6c;

int f(const char *s) {
    int x = 45;
    char c = 's';
    int flag = 1;
    for (int i = 0; i < x; i++) {
        if (s[i] != c) {
            flag = 0;
            break;
        }
    }

    if (memcmp(s + x, &canary, 8) != 0)
        flag = 0;

    return flag;
}

int main() {
    char in[100];
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    fgets(in, 100, stdin);
    int ret = f(in);
    if (ret)
        printf("Well done\n");
    else
        printf("You have failed\n");
    return (ret != 1);
}
